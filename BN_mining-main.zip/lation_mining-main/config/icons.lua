return {

    -- Interactions
    mine = 'fas fa-hammer',
    mine_color = '',

    smelt = 'fas fa-fire',
    smelt_color = '',

    mine_shop = 'fas fa-comment',
    mine_shop_color = '',

    -- Player data menu
    player_level = 'fas fa-chart-simple',
    player_level_color = '',

    view_stats = 'fas fa-chart-pie',
    view_stats_color = '',

    -- Stats menu
    stats_mined = 'fas fa-hammer',
    stats_mined_color = '',

    stats_smelted = 'fas fa-fire',
    stats_smelted_color = '',

    stats_earned = 'fas fa-dollar-sign',
    stats_earned_color = '',

    -- The Mines menu
    mines_leaderboard = 'fas fa-ranking-star',
    mines_leaderboard_color = '',

    mines_shop = 'fas fa-hammer',
    mines_shop_color = '',

    mines_pawn = 'fas fa-sack-dollar',
    mines_pawn_color = '',

    leaderboard = 'fas fa-trophy',

    -- Input menu(s)
    input_quantity = 'fas fa-hashtag',

    -- Text UI
    smelting = 'fas fa-fire'

}